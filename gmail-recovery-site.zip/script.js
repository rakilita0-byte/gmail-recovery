const email = document.getElementById("email");
const button = document.getElementById("recover");
const error = document.getElementById("error");

button.addEventListener("click", () => {
  const value = email.value.trim();

  if (!value || !email.validity.valid) {
    error.textContent = "Please enter a valid Gmail address.";
    error.style.display = "block";
    email.focus();
    return;
  }

  error.style.display = "none";

  // The address is passed to Google's official recovery page.
  // This site does not collect or transmit passwords or verification codes.
  const url = "https://accounts.google.com/signin/recovery?Email=" +
              encodeURIComponent(value);

  window.location.href = url;
});
