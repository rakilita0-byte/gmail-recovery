# Account Recovery Guide

A simple static website for helping users recover access to their own Google/Gmail accounts.

## Files
- index.html
- style.css
- script.js

## Hosting
Upload all three files to any static web host.

## Important
This site deliberately does NOT collect:
- Google passwords
- PINs or OTPs
- recovery codes
- authentication tokens

The "Continue to Google Recovery" button sends the user to Google's official account recovery page.

This project is an independent guide and is not affiliated with Google.
